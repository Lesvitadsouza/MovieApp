About the Movie Application:

This is a simple movie application which will provide information of a particular movie

The project consists of a .json object data namely movie_mock_data.php whih stores all the movies with their respective key, name, description, rating, length and image.

The first page (http://localhost/Lesvita/index.html#!/) consists of a search area to search the movie by name which on clicking on the image redirects to the second page which conatins basic  information on the searched movie.

the main.html page in the template folder handles the view of first page and the single.html page in the same folder handles the seconf view view pertaining to the movie clicked

Further, one can also click on the movie poster directly to access information about the movie.

The movie application is kept simple with basic Boostrap and css styling. Also this application is developed using AngularJs 1.6